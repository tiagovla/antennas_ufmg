python -m nec.opt -e nec2 $*
