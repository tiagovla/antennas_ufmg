python -m nec.eval -e nec2 $*
